SELECT 
    MIN(precio_unitario) AS precio_minimo,
    MAX(precio_unitario) AS precio_maximo,
    AVG(precio_unitario) AS precio_promedio
FROM Producto;


SELECT 
    s.nombre AS nombre_sucursal,
    SUM(st.cantidad) AS cantidad_total_en_stock
FROM Stock st
JOIN Sucursal s ON st.sucursal_id = s.id
GROUP BY s.nombre;


SELECT 
    c.nombre AS nombre_cliente,
    SUM(i.monto_venta) AS total_ventas
FROM Cliente c
JOIN Orden o ON c.id = o.cliente_id
JOIN Item i ON o.id = i.orden_id
GROUP BY c.nombre;
